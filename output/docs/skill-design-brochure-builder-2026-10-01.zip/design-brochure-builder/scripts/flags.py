"""Country-flag pipeline for gcs-brochure-builder.

Flags come exclusively from the design system's assets/flags/ (self-hosted PNGs
from msikma/country-flags — never flagcdn, Wikipedia, or any other source,
per skills/gcs-table-chart/references/flags.md's 2026-07 policy). Most codes
are already PNG (no rasterization needed — PptxGenJS's
`addImage({rounding: true})` does the circular crop at the OOXML level, so
this module never pre-crops). A handful of territories/UK-sub-nations/Kosovo
only exist as legacy .svg in assets/flags/ and are rasterized on demand via
the same cairosvg helper icons.py uses.

Usage (CLI):
    python3 scripts/flags.py it            # -> assets/flags/it.png
    python3 scripts/flags.py xk --size 42  # legacy .svg -> rasterized PNG
"""

import os
import sys
from pathlib import Path

from icons import MissingAsset

SKILL_DIR = Path(__file__).resolve().parent.parent
GENERATED_DIR = SKILL_DIR / "assets" / "flags" / "_generated"

# Flag libraries, first hit wins: an explicit GCS_DESIGN_SYSTEM_DIR checkout,
# the sibling gcs-design-system repo (Github/gcs-design-system), this repo's
# own assets/, then a skill-local assets/flags/.
def _flag_dirs():
    dirs = []
    env_root = os.environ.get("GCS_DESIGN_SYSTEM_DIR")
    if env_root:
        dirs.append(Path(env_root) / "assets" / "flags")
    dirs.append(SKILL_DIR.parents[2] / "gcs-design-system" / "assets" / "flags")
    dirs.append(SKILL_DIR.parents[1] / "assets" / "flags")
    dirs.append(SKILL_DIR / "assets" / "flags")
    return dirs

# The repo's local copy names the UK flag gb.png (upstream msikma/country-flags
# calls it uk.png) — always resolve through this alias so either code works.
ALIASES = {"uk": "gb"}


def _square_crop(png_path: Path, code: str, size_px: int) -> Path:
    """Center-crop a flag to a square (CSS object-fit: cover equivalent) so the
    circular `rounding: true` crop in PptxGenJS never distorts a 3:2 flag."""
    from PIL import Image
    GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    out_path = GENERATED_DIR / f"{code}-sq-{size_px}.png"
    if not out_path.exists():
        im = Image.open(png_path).convert("RGB")
        side = min(im.size)
        left, top = (im.width - side) // 2, (im.height - side) // 2
        im.crop((left, top, left + side, top + side)).resize((size_px, size_px), Image.LANCZOS).save(out_path)
    return out_path


def resolve_flag_path(iso2: str, size_px: int = 42) -> Path:
    code = ALIASES.get(iso2.lower(), iso2.lower())
    checked = []

    for flags_dir in _flag_dirs():
        png_path = flags_dir / f"{code}.png"
        checked.append(str(png_path))
        if png_path.exists():
            return _square_crop(png_path, code, size_px)

        svg_path = flags_dir / f"{code}.svg"
        if svg_path.exists():
            svg_markup = svg_path.read_text(encoding="utf-8")
            # Flags keep their own multi-color artwork — recolor is a no-op here,
            # but _rasterize_and_cache always recolors the root <svg>'s fill, which
            # would corrupt a multi-path flag. Rasterize directly instead.
            import cairosvg
            GENERATED_DIR.mkdir(parents=True, exist_ok=True)
            out_path = GENERATED_DIR / f"{code}-{size_px}.png"
            if not out_path.exists():
                cairosvg.svg2png(bytestring=svg_markup.encode("utf-8"), write_to=str(out_path),
                                  output_width=size_px, output_height=size_px)
            return out_path

    raise MissingAsset(
        f"No flag found for ISO2 code '{iso2}' (checked {', '.join(checked)}). "
        "Never substitute a placeholder — ask the user for the correct country code."
    )


def get_flag_png(iso2: str, size_px: int = 42) -> Path:
    return resolve_flag_path(iso2, size_px=size_px)


def _main(argv):
    import argparse

    parser = argparse.ArgumentParser(description="Resolve/rasterize a GCS brochure country flag to PNG.")
    parser.add_argument("iso2")
    parser.add_argument("--size", type=int, default=42)
    args = parser.parse_args(argv)
    print(get_flag_png(args.iso2, size_px=args.size))


if __name__ == "__main__":
    _main(sys.argv[1:])
