#!/usr/bin/env node
/**
 * Detect drift between a design-system brochure template and this skill's port.
 *
 * Compares the props a template reads (`this.props.<name>` in its
 * renderVals()) with the keys in scripts/templates/<name>.json's propsSchema
 * (+ droppedProps). Any prop the template renders that the schema doesn't know
 * — or a schema prop the template no longer reads — means the template changed
 * and scripts/components/<name>.js needs re-measuring (see SKILL.md,
 * "Template sync").
 *
 * Usage: node scripts/check-template-sync.js factsheet [path/to/Template.dc.html]
 * Default template path: $GCS_DESIGN_SYSTEM_DIR or the sibling gcs-design-system repo.
 */
const fs = require('fs');
const path = require('path');
const { getTemplateSchema } = require('./template-registry');

const FILES = { factsheet: 'factsheet/Factsheet.dc.html', 'case-study': 'case-study/CaseStudy.dc.html', 'quarterly-report': 'quarterly-report/QuarterlyReport.dc.html' };

const [, , name, fileArg] = process.argv;
if (!name) {
  console.error('Usage: node scripts/check-template-sync.js <template-name> [Template.dc.html]');
  process.exit(2);
}
const dsRoot = process.env.GCS_DESIGN_SYSTEM_DIR || path.resolve(__dirname, '..', '..', '..', '..', 'gcs-design-system');
const htmlPath = fileArg || path.join(dsRoot, 'templates', 'brochures', FILES[name] || `${name}/${name}.dc.html`);
if (!fs.existsSync(htmlPath)) {
  console.error(`Template not found: ${htmlPath}`);
  process.exit(2);
}

const html = fs.readFileSync(htmlPath, 'utf8');
const used = new Set([...html.matchAll(/this\.props\.(\w+)/g)].map((m) => m[1]));
const schema = getTemplateSchema(name);
const known = new Set([...Object.keys(schema.propsSchema || {}), ...Object.keys(schema.droppedProps || {})]);
// Props the port adds on top of the template (not read by renderVals()).
const PORT_ONLY = new Set(['flagIso2']);

const newInTemplate = [...used].filter((k) => !known.has(k));
const goneFromTemplate = [...known].filter((k) => !used.has(k) && !PORT_ONLY.has(k) && !(schema.propsSchema[k] || {}).optional);

if (!newInTemplate.length && !goneFromTemplate.length) {
  console.log(`${name}: props in sync with ${path.relative(process.cwd(), htmlPath)} (${used.size} props).`);
  process.exit(0);
}
if (newInTemplate.length) console.log(`Read by the template but missing from scripts/templates/${name}.json: ${newInTemplate.join(', ')}`);
if (goneFromTemplate.length) console.log(`In scripts/templates/${name}.json but no longer read by the template: ${goneFromTemplate.join(', ')}`);
console.log('Re-measure the template and update the schema, mapper and component (SKILL.md "Template sync").');
process.exit(1);
